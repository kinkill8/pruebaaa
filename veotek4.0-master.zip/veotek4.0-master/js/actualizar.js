$(document).ready(function(){
	$('.actualizar').click(function(){
		$('.container').hide();
	});

});