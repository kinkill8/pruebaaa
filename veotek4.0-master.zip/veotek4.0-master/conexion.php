<?php
$conexion = mysql_connect("localhost", "root", "veotek");
mysql_select_db("veotek3",$conexion);
?>